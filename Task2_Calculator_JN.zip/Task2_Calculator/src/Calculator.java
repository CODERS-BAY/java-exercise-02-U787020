public class Calculator {
    public static void main(String[] args) {
       int x = 9;
       int y = 5;

       System.out.println(x+y);
       System.out.println(x-y);
       System.out.println(x*y);
       System.out.println(x/y);
       System.out.println(x%y);

       float a = 9;
       float b = 5;

        System.out.println(a+b);
        System.out.println(a-b);
        System.out.println(a*b);
        System.out.println(a/b);
        System.out.println(a%b);
    }
}
